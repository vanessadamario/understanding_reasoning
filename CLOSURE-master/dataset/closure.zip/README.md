# CLOSURE dataset

The format of all files is the same as in the [original CLEVR release](https://cs.stanford.edu/people/jcjohns/clevr/).

Validation, test, training and baseline questions are included. Most of baseline questions are copied from the original CLEVR release, with the exception
of `or_mat` and `or_mat_spa` questions. Those are generated us, for reasons outlined in Appendix D of the paper.
